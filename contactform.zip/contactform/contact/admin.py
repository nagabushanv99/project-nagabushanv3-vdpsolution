from django.contrib import admin
# from django.contrib.auth.admin import UserAdmin

# Register your models here.
from .models import Contact


class ContactAdmin(admin.ModelAdmin):
    list_display = ('name', 'number', 'email', 'subject')
    search_fields = ('name', 'number', 'email', 'subject')

    filter_horizontal = ()
    list_filter = ()
    fieldsets = ()

admin.site.register(Contact, ContactAdmin)