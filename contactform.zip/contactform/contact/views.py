from django.shortcuts import render
from .models import Contact
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html')

def services(request):
    return render(request,'services.html')

def portfolio(request):
    return render(request,'portfolio.html')

def contact(request):
    if request.method == 'POST':
        contact = Contact()
        name = request.POST.get('name')
        number = request.POST.get('number')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        contact.name = name
        contact.number = number
        contact.email = email
        contact.subject = subject
        contact.save()
        html = '<html><body style="text-align: center; color: #ffffff; background-color: #15123d"><h1 style="margin-top: 40vh">Your response has been submitted</h1><h2>See our <a href="portfolio" style="color:#ffffff">Works</a></h2></body></html>'
        return HttpResponse(html)

    return render(request,'contact.html')